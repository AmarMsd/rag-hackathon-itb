"""Tools agen edge WeselGuard. Semua berjalan lokal di Raspberry Pi."""
import json
import math
import re
from datetime import datetime
from pathlib import Path

DATA = Path(__file__).parent / "data"


def _baca(nama):
    return json.loads((DATA / nama).read_text(encoding="utf-8"))


def _tulis(nama, isi):
    (DATA / nama).write_text(json.dumps(isi, indent=2, ensure_ascii=False), encoding="utf-8")


def _token(teks):
    return re.findall(r"[a-z0-9]+", teks.lower().replace("_", " "))


def deteksi_anomali(wesel_id: str) -> dict:
    """Mengambil hasil deteksi Lapis 1 (bukan LLM) untuk satu wesel.

    Args:
        wesel_id: ID wesel, contoh "W-12".

    Returns:
        Kondisi kandidat, skor kecocokan (0-1), indeks kesehatan (0-100), dan ciri sinyal.
    """
    data = _baca("hasil_deteksi.json")
    if wesel_id not in data:
        return {"status": "error", "pesan": f"Tidak ada data deteksi untuk {wesel_id}."}
    return {"status": "ok", "wesel_id": wesel_id, **data[wesel_id]}


def cari_manual(gejala: str, bab: int = 0) -> dict:
    """Mencari subbab manual yang paling relevan dengan gejala (RAG berbasis kata kunci).

    Args:
        gejala: Deskripsi gejala atau kondisi, contoh "kurtosis tinggi bantalan aus".
        bab: Batasi ke bab tertentu (3 gejala, 4 urgensi, 5 langkah). 0 berarti semua bab.

    Returns:
        Maksimal dua subbab manual yang paling relevan.
    """
    manual = _baca("manual.json")
    kandidat = [s for s in manual if bab in (0, s["bab"])]
    dok = [_token(s["judul"] + " " + s["isi"]) for s in kandidat]
    n = len(dok)
    kueri = set(_token(gejala))
    skor = []
    for s, kata in zip(kandidat, dok):
        nilai = 0.0
        for k in kueri:
            df = sum(1 for d in dok if k in d)
            if k in kata:
                nilai += kata.count(k) * math.log(1 + n / df)
        skor.append((nilai, s))
    hasil = [{"id": s["id"], "judul": s["judul"], "isi": s["isi"]}
             for nilai, s in sorted(skor, key=lambda x: -x[0]) if nilai > 0][:2]
    if not hasil:
        return {"status": "kosong", "pesan": "Tidak ada subbab relevan. Coba kata kunci lain."}
    return {"status": "ok", "hasil": hasil}


def cek_riwayat(wesel_id: str) -> dict:
    """Membaca kejadian dan keputusan petugas sebelumnya pada wesel yang sama.

    Args:
        wesel_id: ID wesel, contoh "W-12".

    Returns:
        Daftar kejadian sebelumnya beserta keputusan dan catatan petugas.
    """
    riwayat = [r for r in _baca("riwayat.json") if r["wesel_id"] == wesel_id]
    return {"status": "ok", "jumlah": len(riwayat), "kejadian": riwayat}


def nilai_urgensi(indeks_kesehatan: int, kejadian_berulang: bool) -> dict:
    """Menentukan Klasifikasi A, B, atau C sesuai Bab 4 manual (aturan pasti, bukan tebakan).

    Args:
        indeks_kesehatan: Indeks kesehatan 0-100 dari deteksi_anomali.
        kejadian_berulang: True jika kerusakan yang sama pernah terjadi dan ditangani (lihat cek_riwayat).

    Returns:
        Kelas urgensi, tenggat penanganan, dan alasan.
    """
    if indeks_kesehatan < 40:
        kelas = "A"
    elif indeks_kesehatan < 70:
        kelas = "B"
    else:
        kelas = "C"
    alasan = f"Indeks kesehatan {indeks_kesehatan} menghasilkan Klasifikasi {kelas} (Bab 4.1)."
    if kejadian_berulang and kelas != "A":
        kelas = {"C": "B", "B": "A"}[kelas]
        alasan += f" Kejadian berulang, dinaikkan menjadi Klasifikasi {kelas}."
    tenggat = {"A": "24 jam", "B": "7 hari", "C": "pemeriksaan rutin berikutnya"}[kelas]
    return {"status": "ok", "kelas": kelas, "tenggat": tenggat, "alasan": alasan}


def buat_work_order(wesel_id: str, kondisi: str, kelas: str, ringkasan: str) -> dict:
    """Menyusun work order berisi langkah pemeriksaan Bab 5, berstatus menunggu persetujuan petugas.

    Args:
        wesel_id: ID wesel.
        kondisi: Kondisi hasil diagnosis, contoh "bantalan_aus" atau "poros_tidak_sejajar".
        kelas: Kelas urgensi dari nilai_urgensi ("A", "B", atau "C").
        ringkasan: Penjelasan singkat diagnosis dan alasannya untuk petugas.

    Returns:
        Work order yang tersimpan dengan status MENUNGGU_PERSETUJUAN.
    """
    langkah = next((s for s in _baca("manual.json") if s.get("kondisi") == kondisi), None)
    if langkah is None:
        return {"status": "error", "pesan": f"Bab 5 tidak memuat langkah untuk '{kondisi}'. Pertimbangkan eskalasi."}
    daftar = _baca("work_orders.json")
    wo = {
        "id": f"WO-{len(daftar) + 1:03d}",
        "wesel_id": wesel_id,
        "kondisi": kondisi,
        "kelas": kelas,
        "ringkasan": ringkasan,
        "langkah": langkah["isi"],
        "rujukan": f"Manual {langkah['id']}",
        "status": "MENUNGGU_PERSETUJUAN",
        "dibuat": datetime.now().isoformat(timespec="seconds"),
    }
    daftar.append(wo)
    _tulis("work_orders.json", daftar)
    return {"status": "ok", "work_order": wo}


def eskalasi(wesel_id: str, alasan: str) -> dict:
    """Meminta teknisi ahli memeriksa langsung saat pola tidak dikenal atau data meragukan.

    Args:
        wesel_id: ID wesel.
        alasan: Mengapa agen tidak bisa menyimpulkan sendiri.

    Returns:
        Konfirmasi permintaan eskalasi.
    """
    daftar = _baca("work_orders.json")
    item = {
        "id": f"ESK-{len(daftar) + 1:03d}",
        "wesel_id": wesel_id,
        "jenis": "ESKALASI",
        "alasan": alasan,
        "status": "MENUNGGU_TEKNISI_AHLI",
        "dibuat": datetime.now().isoformat(timespec="seconds"),
    }
    daftar.append(item)
    _tulis("work_orders.json", daftar)
    return {"status": "ok", "eskalasi": item}
